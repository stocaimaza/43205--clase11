//1) Voy a importar el Hook useState y createContext que me permite crear un contexto que va almacenar toda la lógica de mi carrillo de compras. 

import { useState, createContext } from "react";

//2)Creamos el nuevo contexto. 
//El valor inicial por default es un objeto con la propiedad "carrito" con un array vacío. 

export const CarritoContext = createContext({ carrito: [] });

//Creamos el componente "CarritoProvider". También lo pueden encontrar en el material teorico como el proveedor de contextos. 

export const CarritoProvider = ({ children }) => {
    //3) Creamos un estado local llamado "carrito" con el hook useState. 
    const [carrito, setCarrito] = useState([]);

    //Verificamos por consola (no se olviden de esto!); 
    console.log(carrito);

    //Agregamos algunos métodos al proveedor para manipular el carrito de compras: 

    //Agregar productos al carrito: 
    const agregarProducto = (item, cantidad) => {
        //Verificamos si el producto ya esta en el carrito. 
        const productoExistente = carrito.find(prod => prod.item.id === item.id);

        if (!productoExistente) {
            //Si el producto no existe, lo agregamos al carrito
            setCarrito(prev => [...prev, { item, cantidad }]);
        } else {
            //Si el producto ya existe, actualizamos su cantidad: 
            const carritoActualizado = carrito.map(prod => {
                if (prod.item.id === item.id) {
                    return { ...prod, cantidad: prod.cantidad + cantidad };
                } else {
                    return prod;
                }
            });
            setCarrito(carritoActualizado);
        }
    }

    //Función para eliminar productos del carrito: 

    const eliminarProducto = (id) => {
        const carritoActualizado = carrito.filter(prod => prod.id !== id);
        setCarrito(carritoActualizado);
    }

    //Función para vaciar el carrito de compras: 
    const vaciarCarrito = () => {
        setCarrito([]);
    }

    //5) Usamos el componente CarritoContext.Provider para enviar el valor actual del carrito y los métodos a los componentes de mi app que lo necesiten. 

    return (
        <CarritoContext.Provider value={{ carrito, agregarProducto, eliminarProducto, vaciarCarrito }}>
            {children}

        </CarritoContext.Provider>
    )
}

//6)Children: propiedad especial que se utiliza para representar a todos aquellos componentes que puedan necesitar el carrito y sus métodos. 